BLUO CLIENT Bedrock Resource Pack Template

This is a valid starting manifest for an original resource pack. It currently contains no texture or UI overrides, so importing it will not visibly change Minecraft yet.

To test: zip the CONTENTS of this folder (manifest.json must be at the zip root), then rename the .zip to .mcpack and open it with Minecraft. Some file managers may require enabling filename extensions first.

Only add original assets or assets you have permission to use. Resource packs cannot provide unrestricted access to Minecraft internals or guarantee FPS/FOV changes.
