# BLUO CLIENT — Android companion v1.1.0

An original native Android Kotlin companion dashboard for Minecraft Bedrock, branded **BLUO CLIENT** with a dark blue/purple theme.

## Features in this source project
- Home dashboard and navigation
- Performance checklist with saved choices
- HUD preview with saved visibility toggles (preview only)
- Resource-pack import guide
- Settings page, compatibility notes, and reset preferences action
- `bedrock-pack-template/manifest.json` as a starter resource-pack manifest

## Important limitations
This is a companion app, not a modified Minecraft APK or a complete in-game client. It does not inject code into Minecraft, change game files, force FPS/FOV, measure live ping, or render an overlay inside the game. The HUD editor is a preview and its toggles are app-local. The included Bedrock pack is only a manifest template with no visible assets yet. Build and test with the Android SDK and a real device before distributing.

No Blueberry Client source code or proprietary assets are included. BLUO uses an original visual direction rather than a pixel-perfect copy.

## Build
Open the project in Android Studio with Android SDK Platform 35 installed, sync Gradle, then build the debug APK. Android Gradle Plugin 8.7.3 and Kotlin 2.0.21 are configured. This project does not include a Gradle wrapper, so use an installed Gradle version compatible with the Android plugin.

## Package
`com.bluo.client`
