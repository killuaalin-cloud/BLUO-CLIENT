package com.bluo.client

import android.app.Activity
import android.app.AlertDialog
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.widget.*

class MainActivity : Activity() {
    private val bg = Color.rgb(9, 11, 20)
    private val panel = Color.rgb(20, 23, 39)
    private val blue = Color.rgb(76, 142, 255)
    private val purple = Color.rgb(124, 92, 255)
    private val white = Color.rgb(241, 243, 255)
    private val muted = Color.rgb(157, 164, 190)
    private lateinit var root: LinearLayout
    private lateinit var content: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        applyKeepAwakePreference()
        showPage("Home")
    }

    private fun showPage(page: String) {
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(bg); setPadding(dp(18), dp(18), dp(18), dp(10)) }
        val scroll = ScrollView(this)
        content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        val nav = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; setPadding(0, dp(8), 0, 0) }
        listOf("Home", "Performance", "HUD", "Packs", "Settings").forEach { name ->
            val b = Button(this).apply {
                text = name
                textSize = 9f
                setTextColor(if (name == page) Color.WHITE else muted)
                background = rounded(if (name == page) purple else panel, 14)
                isAllCaps = false
                setOnClickListener { showPage(name) }
            }
            nav.addView(b, LinearLayout.LayoutParams(0, dp(48), 1f).apply { setMargins(dp(2), 0, dp(2), 0) })
        }
        root.addView(nav)
        setContentView(root)
        when (page) {
            "Home" -> home()
            "Performance" -> performance()
            "HUD", "HUD Editor" -> hud()
            "Packs" -> packs()
            else -> settings()
        }
    }

    private fun home() {
        label("BLUO", 15, blue, true, 2)
        label("CLIENT", 34, white, true, 0)
        label("BEDROCK COMPANION  •  v1.0.0", 11, muted, true, 18)
        card {
            label("Welcome back, Player", 20, white, true, 5)
            label("Your Minecraft companion dashboard", 13, muted, false, 14)
            action("OPEN PERFORMANCE", blue) { showPage("Performance") }
            action("CUSTOMIZE HUD", purple) { showPage("HUD") }
        }
        card {
            label("QUICK STATUS", 12, blue, true, 10)
            label("Client shell: Ready", 15, white, true, 4)
            label("Game integration: Not connected", 13, muted, false, 4)
            label("This app does not modify Minecraft by itself. Use the guides and supported Bedrock packs below.", 12, muted, false, 0)
        }
        card {
            label("DESIGNED FOR MOBILE", 12, purple, true, 8)
            label("Clean controls • Lightweight UI • PvP-focused tools", 14, white, false, 0)
        }
    }

    private fun performance() {
        label("PERFORMANCE", 26, white, true, 4)
        label("Practical settings for smoother Bedrock gameplay", 13, muted, false, 16)
        card {
            label("IN-GAME CHECKLIST", 13, blue, true, 8)
            prefCheck("Lower render distance", true, "perf_render")
            prefCheck("Turn off fancy graphics", true, "perf_fancy")
            prefCheck("Reduce particles", true, "perf_particles")
            prefCheck("Close background apps before playing", false, "perf_apps")
            prefCheck("Use a stable Wi-Fi connection", false, "perf_wifi")
        }
        card {
            label("DEVICE TIPS", 13, purple, true, 8)
            label("• Keep the phone cool.\n• Leave free storage space.\n• Use the highest refresh rate available in Android settings.\n• Avoid third-party apps claiming to unlock FPS or change game files.", 13, white, false, 0)
        }
        label("These are recommendations only; Android apps cannot safely force Minecraft's FPS or graphics settings without supported game integration.", 11, muted, false, 12)
    }

    private fun hud() {
        label("HUD EDITOR", 26, white, true, 4)
        label("Preview and customize a simple overlay layout", 13, muted, false, 14)
        val preview = FrameLayout(this).apply { setBackgroundColor(Color.rgb(31, 42, 52)); minimumHeight = dp(250) }
        val sky = TextView(this).apply { text = "BLUO HUD PREVIEW"; textSize = 12f; setTextColor(Color.WHITE); gravity = Gravity.CENTER; setBackgroundColor(Color.rgb(51, 78, 93)) }
        preview.addView(sky, FrameLayout.LayoutParams(-1, -1))
        val fps = TextView(this).apply { text = "FPS: 60\nPING: --"; textSize = 12f; setTextColor(Color.WHITE); setPadding(dp(8), dp(6), dp(8), dp(6)); setBackgroundColor(0xAA111827.toInt()) }
        val fp = FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.START).apply { leftMargin = dp(10); topMargin = dp(10) }
        preview.addView(fps, fp)
        val cross = TextView(this).apply { text = "+"; textSize = 28f; setTextColor(Color.WHITE); gravity = Gravity.CENTER }
        preview.addView(cross, FrameLayout.LayoutParams(dp(50), dp(50), Gravity.CENTER))
        content.addView(preview, LinearLayout.LayoutParams(-1, dp(250)).apply { bottomMargin = dp(12) })
        card {
            label("OVERLAY ELEMENTS", 13, blue, true, 8)
            prefCheck("FPS counter (preview only)", true, "hud_fps") { fps.visibility = if (it) View.VISIBLE else View.GONE }
            prefCheck("Crosshair (preview only)", true, "hud_crosshair") { cross.visibility = if (it) View.VISIBLE else View.GONE }
            prefCheck("Ping label (preview only)", false, "hud_ping") {
                if (it) fps.text = "FPS: --\nPING: --" else fps.text = "FPS: 60"
            }
            label("This is a visual preview, not an overlay inside Minecraft. Drag editing and in-game injection are not implemented in this starter build.", 11, muted, false, 0)
        }
    }

    private fun packs() {
        label("RESOURCE PACKS", 26, white, true, 4)
        label("Use trusted packs compatible with your Bedrock version", 13, muted, false, 14)
        card {
            label("HOW TO IMPORT", 13, blue, true, 8)
            label("1. Download a compatible .mcpack file.\n2. Open the file with Minecraft.\n3. Enable it in Settings → Global Resources or the world's Resource Packs tab.", 13, white, false, 12)
            action("OPEN MINECRAFT SETTINGS HELP", purple) {
                AlertDialog.Builder(this).setTitle("Resource packs").setMessage("BLUO CLIENT does not download or install packs automatically. Import .mcpack files through Minecraft and check version compatibility.").setPositiveButton("OK", null).show()
            }
        }
        card {
            label("SAFETY NOTE", 13, purple, true, 8)
            label("Avoid packs or tools that ask for your Microsoft password, disable device security, or promise unfair multiplayer advantages.", 13, white, false, 0)
        }
    }


    private fun settings() {
        label("SETTINGS", 26, white, true, 4)
        label("Personalize your BLUO companion", 13, muted, false, 14)
        card {
            label("APP PREFERENCES", 13, blue, true, 8)
            prefCheck("Keep screen awake while using app", false, "keep_awake") { applyKeepAwakePreference() }
            prefCheck("Show confirmation before opening guides", true, "confirm_guides")
            prefCheck("Remember checklist choices", true, "remember_checks")
        }
        card {
            label("ABOUT BLUO CLIENT", 13, purple, true, 8)
            label("Version 1.0.0 • Android companion app", 14, white, true, 5)
            label("Built for Minecraft Bedrock players. This app does not modify Minecraft, bypass multiplayer rules, or claim to unlock unsupported FPS/FOV settings.", 12, muted, false, 10)
            action("VIEW COMPATIBILITY NOTES", blue) {
                AlertDialog.Builder(this).setTitle("Compatibility").setMessage("Use the official Minecraft app and import supported .mcpack files through Minecraft. Availability of pack features depends on your Bedrock version and platform. HUD screen here is a preview only.").setPositiveButton("OK", null).show()
            }
            action("RESET APP PREFERENCES", purple) {
                AlertDialog.Builder(this).setTitle("Reset preferences?").setMessage("This clears saved BLUO checklist and display choices.").setNegativeButton("Cancel", null).setPositiveButton("Reset") { _, _ -> getSharedPreferences("bluo_settings", MODE_PRIVATE).edit().clear().apply(); showPage("Settings") }.show()
            }
        }
    }

    private fun prefCheck(text: String, defaultValue: Boolean, key: String, onChange: ((Boolean) -> Unit)? = null) {
        val prefs = getSharedPreferences("bluo_settings", MODE_PRIVATE)
        val c = CheckBox(this).apply {
            this.text = text
            isChecked = prefs.getBoolean(key, defaultValue)
            textSize = 13f
            setTextColor(white)
            buttonTintList = android.content.res.ColorStateList.valueOf(blue)
            setOnCheckedChangeListener { _, checked ->
                prefs.edit().putBoolean(key, checked).apply()
                onChange?.invoke(checked)
            }
        }
        content.addView(c)
    }

    private fun applyKeepAwakePreference() {
        val enabled = getSharedPreferences("bluo_settings", MODE_PRIVATE).getBoolean("keep_awake", false)
        if (enabled) window.addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        else window.clearFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }

    private fun card(block: LinearLayout.() -> Unit) {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(15), dp(16), dp(15)); background = rounded(panel, 20) }
        box.block()
        content.addView(box, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(12) })
    }

    private fun label(text: String, size: Int, color: Int, bold: Boolean, bottom: Int) {
        val t = TextView(this).apply { this.text = text; textSize = size.toFloat(); setTextColor(color); if (bold) setTypeface(typeface, Typeface.BOLD); setPadding(0, 0, 0, dp(bottom)) }
        content.addView(t)
    }

    private fun LinearLayout.label(text: String, size: Int, color: Int, bold: Boolean, bottom: Int) {
        addView(TextView(this@MainActivity).apply { this.text = text; textSize = size.toFloat(); setTextColor(color); if (bold) setTypeface(typeface, Typeface.BOLD); setPadding(0, 0, 0, dp(bottom)) })
    }

    private fun check(text: String, checked: Boolean) {
        val c = CheckBox(this).apply { this.text = text; isChecked = checked; textSize = 13f; setTextColor(white); buttonTintList = android.content.res.ColorStateList.valueOf(blue) }
        content.addView(c)
    }

    private fun LinearLayout.check(text: String, checked: Boolean) {
        addView(CheckBox(this@MainActivity).apply { this.text = text; isChecked = checked; textSize = 13f; setTextColor(white); buttonTintList = android.content.res.ColorStateList.valueOf(blue) })
    }

    private fun action(text: String, color: Int, run: () -> Unit) {
        val b = Button(this).apply { this.text = text; textSize = 12f; isAllCaps = false; setTextColor(Color.WHITE); background = rounded(color, 14); setOnClickListener { run() } }
        content.addView(b, LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(6) })
    }

    private fun LinearLayout.action(text: String, color: Int, run: () -> Unit) {
        val b = Button(this@MainActivity).apply { this.text = text; textSize = 12f; isAllCaps = false; setTextColor(Color.WHITE); background = rounded(color, 14); setOnClickListener { run() } }
        addView(b, LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(6) })
    }

    private fun rounded(color: Int, radius: Int): android.graphics.drawable.GradientDrawable = android.graphics.drawable.GradientDrawable().apply { setColor(color); cornerRadius = dp(radius).toFloat() }
    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
